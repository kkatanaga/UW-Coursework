package a2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({UnitTest.class})

public class UnitTestSuite {
	// the class remains empty,
	// used only as a holder for the above annotations
}